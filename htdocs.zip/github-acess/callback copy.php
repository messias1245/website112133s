<?php
// callback.php

// Incluir a biblioteca do GitHub
require_once 'vendor/autoload.php';


// Configurar as credenciais do aplicativo do GitHub
$clientID = 'bf650749b7f0411b4f95';
$clientSecret = '3c574e3200e759140149a210e4ea4fa54a4f3bf6';
$redirectUri = 'http://localhost/callback.php';

// Criar uma instância do cliente do GitHub
$client = new \Github\Client();

// Verificar se o código de autorização está presente na URL
if (isset($_GET['code'])) {
    // Obter o código de autorização
    $code = $_GET['code'];

    try {
        // Obter o token de acesso usando o código de autorização
        $accessToken = $client->authenticate($clientID, $clientSecret, \Github\Client::AUTH_URL_ACCESS_TOKEN, $code);
        
        // Autenticar o cliente usando o token de acesso
        $client->authenticate($accessToken, null, \Github\Client::AUTH_ACCESS_TOKEN);

        // Obter os detalhes do usuário autenticado
        $user = $client->api('current_user')->show();

        // Processar os dados do usuário
        $username = $user['login'];
        $name = $user['name'];
        $email = $user['email'];
        // ... faça o que desejar com os dados do usuário

        // Redirecionar o usuário para a página de sucesso ou dashboard
        header('Location: http://localhost/dashboard.php');
        exit();
    } catch (\Github\Exception\RuntimeException $e) {
        // Ocorreu um erro na autenticação
        echo 'Erro na autenticação: ' . $e->getMessage();
    }
} else {
    // Código de autorização não está presente na URL, redirecionar para a página de login
    header('Location: http://localhost/index.php');
    exit();
}
?>
