<?php

$name = "Smurf-Vendas";         // Application Name
$ownerid = "MxZq9OGzmy";      // Application OwnerID

?>