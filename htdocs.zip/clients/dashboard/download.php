<?php
$file = $_GET['file'];

if (isset($file) && !empty($file)) {
  $filepath = 'spoofer' . $file;

  if (file_exists($filepath)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename=' . basename($filepath));
    header('Content-Length: ' . filesize($filepath));
    readfile($filepath);
    exit;
  } else {
    die('O arquivo solicitado não existe.');
  }
} else {
  die('O arquivo não foi especificado.');
}
?>
